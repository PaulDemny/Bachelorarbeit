/**
 * 
 */
package loader;

import java.net.URL;

/**
 * @author Paul
 *
 */
public class StrategyLoader {
	
	public StrategyLoader() {
		
	}
	
}
