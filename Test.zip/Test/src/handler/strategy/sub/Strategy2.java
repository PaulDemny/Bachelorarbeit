package handler.strategy.sub;

import handler.strategy.IStrategy;

public class Strategy2 implements IStrategy {

	private final String NAME;
	
	public Strategy2() {
		this.NAME = "Strategy2";
	}
	@Override
	public void execute() {
		System.out.println("HAllo");

	}

	@Override
	public String getName() {
		return this.NAME;
	}

}
