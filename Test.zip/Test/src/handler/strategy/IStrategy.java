/**
 * 
 */
package handler.strategy;

/**
 * @author Paul
 *
 */
public interface IStrategy {
	void execute();
	String getName();
}
