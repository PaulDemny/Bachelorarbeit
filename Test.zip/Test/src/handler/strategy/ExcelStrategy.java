/**
 * 
 */
package handler.strategy;

/**
 * @author Paul
 *
 */
public class ExcelStrategy implements IStrategy {

	private final String NAME;
	
	public  ExcelStrategy() {
		this.NAME = "Excel";
	}
	/* (non-Javadoc)
	 * @see Strategy.IStrategy#execute()
	 */
	@Override
	public void execute() {
		System.out.println("Excel");
	}

	@Override
	public String getName() {
		return this.NAME;
	}

}
