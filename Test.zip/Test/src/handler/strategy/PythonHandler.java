/**
 * 
 */
package handler.strategy;

/**
 * @author Paul
 *
 */
public class PythonHandler implements IStrategy {

	private final String NAME;
	
	public PythonHandler() {
		this.NAME = "Python";
	}
	/* (non-Javadoc)
	 * @see handler.strategy.IStrategy#execute()
	 */
	@Override
	public void execute() {
		System.out.print("Python");

	}

	@Override
	public String getName() {
		return this.NAME;
	}

}
