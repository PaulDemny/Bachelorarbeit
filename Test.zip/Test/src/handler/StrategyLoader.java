/**
 * 
 */
package handler;

import java.io.File;
import java.io.FilenameFilter;
import java.util.LinkedList;
import java.util.List;

import handler.strategy.IStrategy;

/**
 * @author Paul
 *
 */
public class StrategyLoader {

	private String pkgName;
	private List <IStrategy> strategies;
	
	public StrategyLoader(){
		this.pkgName = "/handler/strategy";
		this.strategies = new LinkedList<>();
		
	}
	
	public void loadStrategies() {
		String[] files = null;
		File dir = new File(StrategyLoader.class.getResource(pkgName).getFile());
		if(dir.exists()) {
			files = dir.list(new FilenameFilter() {
					
				@Override
				public boolean accept(File dir, String name) {
					if(name.endsWith(".class")) {
						return true;
					}else {return false;}
				}
			});
			for(byte i = 0; i < files.length; i++) {
				String className = files[i].substring(0, files[i].length() - 6);
				try {
					Object newStrategy = 
							Class.forName(this.pkgName.replace("/", ".").substring(1, pkgName.length()) + "." + className).newInstance();
					if(newStrategy instanceof IStrategy) {
						this.strategies.add((IStrategy) newStrategy);
						((IStrategy) newStrategy).execute();
					}
					
				} catch (ClassNotFoundException cnfex) {
                    System.err.println(cnfex);
                } catch (InstantiationException iex) {
                    // We try to instantiate an interface
                    // or an object that does not have a 
                    // default constructor
                } catch (IllegalAccessException iaex) {
                    // The class is not public
                }
			}
		}
	}
	
	public IStrategy selectStrategy(String name) {
		IStrategy selection = null;
		for(byte i = 0; i < this.strategies.size(); i++) {
			if(name.equalsIgnoreCase(this.strategies.get(i).getName())) {
				selection = this.strategies.get(i);
			}
		}
		return selection;
	}
}
