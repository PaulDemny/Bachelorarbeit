import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import handler.StrategyLoader;

public class main {

	public static void main(String[] args) {
		File test = new File("E:\\Versionsverwaltung\\Bitbucket\\Test\\bin\\handler\\strategy");
		Path p = Paths.get(test.getAbsolutePath());
		Path g = Paths.get("Hello.doc");
		p = p.resolve(g);
		System.out.println(p + "jjj");
	}
}
