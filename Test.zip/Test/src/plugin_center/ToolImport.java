/**
 * 
 */
package plugin_center;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

/**
 * @author Paul
 *
 */
public class ToolImport {
	
	private final String EXT_EXCEL;
	private final String EXT_PYTHON;
	private final String EXT_DOC;
	
	public ToolImport() {
		this.EXT_EXCEL = ".xlsm";
		this.EXT_PYTHON = ".py";
		this.EXT_DOC = ".pdf";
	}
	
	public List <ToolComposite> analyzeToolFolder(Path mainToolFolder) {
		List <ToolComposite> newTools = new LinkedList<>();
		File[] tools =  mainToolFolder.toFile().listFiles(File::isDirectory);
		for(byte i = 0; i < tools.length; i++) {
			newTools.add(this.analyzeTool(tools[i]));
		}
		return newTools;
	}
	
	public ToolComposite analyzeTool(File toolDirectory) {
		String mainToolName = toolDirectory.getName();
		Path mainToolPath = Paths.get(toolDirectory.getAbsolutePath());
		ToolComposite mainTool = new ToolComposite(mainToolName, mainToolPath);
		mainTool.addSubTool(this.getExcelTool(mainToolPath));
		return mainTool;
	}
	
	public ToolComposite getExcelTool(Path toolfolder) {
		ToolComposite excelTool = null;
		File[] subTools =  toolfolder.toFile().listFiles(File::isFile);
		for (byte i = 0; i < subTools.length; i++) {
			if (subTools[i].getPath().endsWith(this.EXT_EXCEL)) {
				excelTool = new ToolComposite(subTools[i].getName().replace(this.EXT_EXCEL, ""), Paths.get(subTools[i].getAbsolutePath()));
				break;
			}
		}
		return excelTool;
	}
	
	public ToolComposite getPythonTool(Path toolfolder) {
		ToolComposite pythonTool = null;
		Path sourceFolder = toolfolder.resolve("_src");
		File[] subTools =  sourceFolder.toFile().listFiles();
		for (byte i = 0; i < subTools.length; i++) {
			if (subTools[i].getPath().endsWith(this.EXT_PYTHON)) {
				if((subTools[i].getName().equalsIgnoreCase("Dashboard.py"))) {
					pythonTool = new ToolComposite("", sourceFolder.resolve("Dashboard.py"));
				}
				pythonTool = new ToolComposite(subTools[i].getName().replace(this.EXT_EXCEL, ""), Paths.get(subTools[i].getAbsolutePath()));
				break;
			}
		}
		return pythonTool;
	}
	
	public ToolComposite getDocu(Path toolfolder) {
		ToolComposite docTool = null;
		Path docFolder = toolfolder.resolve("_doc");
		File[] subTools =  docFolder.toFile().listFiles();
		for (byte i = 0; i < subTools.length; i++) {
			if (subTools[i].getPath().endsWith(this.EXT_PYTHON)) {
				docTool = new ToolComposite(subTools[i].getName().replace(this.EXT_EXCEL, ""), Paths.get(subTools[i].getAbsolutePath()));
				break;
			}
		}
		return docTool;
	}
}
