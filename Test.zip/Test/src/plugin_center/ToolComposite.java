/**
 * 
 */
package plugin_center;

import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;

import handler.strategy.IStrategy;

/**
 * @author Paul
 *
 */
public class ToolComposite {
	
	private List<ToolComposite> subTools;

	public ToolComposite(String name, Path toolPath) {
		this.subTools = new LinkedList<>();
	}
	
	public ToolComposite(String name, Path toolPath, IStrategy strategy) {
		this.subTools = new LinkedList<>();
	}
	
	public void addSubTool(ToolComposite subTool) {
		this.subTools.add(subTool);
	}
}
